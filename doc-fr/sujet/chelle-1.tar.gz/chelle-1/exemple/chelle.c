
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commande.h"

#ifdef HAS_MALLOC_MTRACE
#include <mcheck.h>
#endif

/*
 * FONCTIONS A FOURNIR
 */
char * historique_precedente()
{
    char * s = calloc(strlen("historique precedente")+1,sizeof(char));
    strcpy(s,"historique precedente");
    return s;
}
char * historique_numero(int i)
{
    char * s = calloc(strlen("historique numero")+12,sizeof(char));
    sprintf(s,"historique numero %d",i);
    return s;
}
char * historique_chaine(const char * c)
{
    char * s = calloc(strlen("historique chaine")+strlen(c)+2,sizeof(char));
    sprintf(s,"historique chaine %s",c);
    return s;
}
void executer_commande(Commande * c)
{
    dump_commande(c,stdout);
}
/*
 *
 */

int main()
{
    char buffer[256];

#ifdef HAS_MALLOC_MTRACE
    if ( getenv("MALLOC_TRACE") == NULL )
        putenv("MALLOC_TRACE=chelle.mtrace");
    mtrace();
#endif

    while ( fgets(buffer,256,stdin) != NULL )
    {
        Commande * c;
        if ( (c=parse_commande(buffer)) != NULL )
        {
            executer_commande(c);
            free_commande(c);
        }
    }

#ifdef HAS_MALLOC_MTRACE
    muntrace();
#endif

    return 0;
}
