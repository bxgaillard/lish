
#ifndef _COMMANDE_POINT_H
#define _COMMANDE_POINT_H

#include <stdio.h>

typedef struct mots Mots;
typedef struct simple Simple;
typedef struct redirfichier RedirFichier;
typedef struct redirdesc RedirDesc;
typedef struct redirection Redirection;
typedef struct redirigee Redirigee;
typedef struct pipeline Pipeline;
typedef enum condop Condop;
typedef struct conditionnelle Conditionnelle;
typedef enum seqop Seqop;
typedef struct sequence Sequence;
typedef struct commande Commande;


struct mots {
    char * mot;
    Mots * suiv;
};

struct simple {
    enum { SIMPLE, SUBSHELL } type;
    union {
        Mots * mots;
        Commande * commande;
    } u;
};

struct redirection {
    enum { FICHIER, DESCRIPTEUR } type;
    union {
        RedirFichier * redirfichier;
        RedirDesc * redirdesc;
    } u;
    Redirection * suiv;
};
struct redirfichier {
    enum { IN, OUT, APP } type;
    int desc;
    char * fichier;
};
struct redirdesc {
    enum { DUP, CLOSE, DUPCLOSE } type;
    int src;
    int dst;
    enum { READ, WRITE } mode;
};

struct redirigee {
    Simple * simple;
    Redirection * redirection;
};

struct pipeline {
    Redirigee * redirigee;
    Pipeline * suiv;
};

enum condop { NOP, AND, OR };
struct conditionnelle {
    Pipeline * pipeline;
    Condop condop;
    Conditionnelle * suiv;
};

enum seqop { SEQ, BACK };
struct sequence {
    Conditionnelle * conditionnelle;
    Seqop seqop;
    Sequence * suiv;
};

struct commande {
    Sequence * sequence;
};

extern Commande * parse_commande(char *);
extern void dump_commande(Commande *, FILE *);
extern void free_commande(Commande *);

#endif
